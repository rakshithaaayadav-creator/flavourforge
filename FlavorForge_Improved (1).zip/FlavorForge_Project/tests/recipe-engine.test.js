const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluateRecipeMatch } = require('../recipe-engine.js');

const recipe = {
  id: 1,
  title: 'Test recipe',
  coreIngredients: [
    { name: 'Eggs', canonical: 'egg' },
    { name: 'Potatoes', canonical: 'potato' },
    { name: 'Onions', canonical: 'onion' }
  ]
};

test('returns 100% when every core ingredient is available', () => {
  const result = evaluateRecipeMatch(recipe, new Set(['egg', 'potato', 'onion']), new Set());
  assert.equal(result.matchPct, 100);
  assert.equal(result.matched.length, 3);
  assert.equal(result.missing.length, 0);
});

test('calculates a partial match and lists missing ingredients', () => {
  const result = evaluateRecipeMatch(recipe, new Set(['egg']), new Set());
  assert.equal(result.matchPct, 33);
  assert.deepEqual(result.missing.map(item => item.canonical), ['potato', 'onion']);
});

test('counts matched expiring ingredients for rescue prioritization', () => {
  const result = evaluateRecipeMatch(recipe, new Set(['egg', 'potato']), new Set(['potato']));
  assert.equal(result.expiringRescueCount, 1);
});

test('returns zero percent for a recipe without core ingredients', () => {
  const result = evaluateRecipeMatch({ id: 2, coreIngredients: [] }, new Set(['egg']), new Set());
  assert.equal(result.matchPct, 0);
  assert.deepEqual(result.matched, []);
  assert.deepEqual(result.missing, []);
});

test('does not mutate the recipe or pantry sets', () => {
  const pantry = new Set(['egg']);
  const expiring = new Set(['egg']);
  evaluateRecipeMatch(recipe, pantry, expiring);
  assert.deepEqual([...pantry], ['egg']);
  assert.deepEqual([...expiring], ['egg']);
  assert.equal(recipe.coreIngredients.length, 3);
});
