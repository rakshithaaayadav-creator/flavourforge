(function (root) {
  "use strict";
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }
  function log(level, event, details = {}) {
    const entry = { timestamp: new Date().toISOString(), app: "FlavorForge", level, event, details };
    const sink = level === "error" ? console.error : level === "warn" ? console.warn : console.info;
    sink("[FlavorForge]", entry);
    return entry;
  }
  root.FlavorForgeUtils = { escapeHTML, log };
})(typeof globalThis !== "undefined" ? globalThis : window);
