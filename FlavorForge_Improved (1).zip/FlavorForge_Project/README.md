# FlavorForge — FridgeRescue

A frontend recipe-matching and kitchen assistant built with HTML5, CSS3, vanilla JavaScript, and Tailwind CSS.

## Project structure

- `index.html` — page structure and application entry point.
- `style.css` — custom visual styles.
- `script.js` — application state, interactions, and UI rendering.
- `recipe-engine.js` — isolated recipe match-scoring domain logic.
- `app-utils.js` — shared HTML escaping and structured logging utilities.
- `recipes.json` — external recipe catalogue (40 recipes).
- `tests/recipe-engine.test.js` — automated unit tests for the core match engine.

The recipe catalogue is loaded as JSON at runtime instead of being embedded in the application script. The recipe engine and shared utilities are loaded separately before the UI application script.

## Run the app

Because the browser fetches `recipes.json`, use a local HTTP server rather than opening `index.html` directly with `file://`.

### Python

```bash
python -m http.server 8000
```

Then open <http://localhost:8000>.

### Node.js (optional)

```bash
npx http-server . -p 8000
```

## Run automated tests

Requires Node.js 18 or newer. No third-party test dependency is required.

```bash
npm test
```

Run JavaScript syntax checks with:

```bash
npm run check
```

## Architecture notes

The project now separates its recipe data, core matching calculation, shared utilities, and browser application entry point. This is a lightweight separation-of-concerns improvement that keeps the current UI and features intact without requiring a framework migration or backend service.

## AI Chef behavior

The AI Chef retains its deterministic local recipe fallback. Provider HTTP failures, request/network failures, timeouts, invalid JSON, empty responses, invalid response schemas, and fallback use are logged as structured events in the browser console. No API key is included in this project; the deterministic fallback remains available when a provider key is not configured.

For production deployment, do not place a private AI provider key in browser JavaScript. Route provider requests through a server-side endpoint that stores secrets securely.
