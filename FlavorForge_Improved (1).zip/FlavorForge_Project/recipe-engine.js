(function (root) {
  "use strict";
  function evaluateRecipeMatch(recipe, pantry, expiring) {
    const coreIngredients = Array.isArray(recipe.coreIngredients) ? recipe.coreIngredients : [];
    const matched = [];
    const missing = [];
    let expiringRescueCount = 0;
    coreIngredients.forEach((item) => {
      if (pantry.has(item.canonical)) {
        matched.push(item);
        if (expiring.has(item.canonical)) expiringRescueCount += 1;
      } else missing.push(item);
    });
    const matchPct = coreIngredients.length ? Math.round(matched.length / coreIngredients.length * 100) : 0;
    return { ...recipe, matched, missing, matchPct, expiringRescueCount };
  }
  const api = { evaluateRecipeMatch };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FlavorForgeRecipeEngine = api;
})(typeof globalThis !== "undefined" ? globalThis : window);
