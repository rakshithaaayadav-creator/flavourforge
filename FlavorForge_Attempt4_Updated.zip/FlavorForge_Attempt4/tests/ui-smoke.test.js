const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('main application views and key controls exist in the HTML', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  for (const id of [
    'view-discover', 'view-ai', 'view-saved', 'pantry-categories',
    'recipes-grid', 'saved-recipes-grid', 'generate-ai-btn',
    'ai-mood-select', 'ai-diet-select', 'toast-container'
  ]) {
    assert.match(html, new RegExp(`id=["']${id}["']`), `Expected #${id} to exist`);
  }
  assert.match(html, /href=["']style\.css["']/, 'Custom stylesheet should be linked');
  assert.match(html, /src=["']script\.js["']/, 'Application script should be linked');
});
