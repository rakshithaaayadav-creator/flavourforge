# FlavorForge — FridgeRescue (Attempt 4 improvements)

A recipe rescue app with separated recipe data/domain logic/UI, automated tests, a small Express API, and SQLite-backed favorites.

## Requirements
- Node.js 18+ (Node 20 LTS recommended)
- npm

## Setup and run
```bash
npm install
# Windows PowerShell: Copy-Item .env.example .env
# macOS/Linux: cp .env.example .env
npm start
```
Open http://localhost:3000. The server creates `data/flavorforge.sqlite` automatically.

The app works without an AI key: AI Chef uses its deterministic local fallback. To enable Gemini, put your key in `.env` as `GEMINI_API_KEY=...`. The key stays on the server and is never sent to browser JavaScript.

## Build
```bash
npm run build
npm start
```
When `dist/` exists, the server serves the production build. `npm run build` uses Vite to prepare optimized static assets.

## Tests and checks
```bash
npm test
npm run check
```
Tests cover recipe matching and server-side input/output validation.

## Architecture
- `index.html`, `style.css`, `script.js` — browser UI.
- `recipe-engine.js` — isolated matching domain logic.
- `app-utils.js` — escaping and structured browser logging.
- `recipes.json` — external recipe catalogue.
- `server.js` — Express API and static-file server.
- `server/db.js` — SQLite connection and schema.
- `server/validation.js` — API input and AI response validation.
- `data/flavorforge.sqlite` — created at runtime; stores favorites.
- `tests/` and `server/*.test.js` — automated tests.

## API routes
- `GET /api/health`
- `GET /api/favorites`
- `PUT /api/favorites/:id`
- `DELETE /api/favorites/:id`
- `POST /api/ai/recipe`

Favorites are shared among users of this single-instance prototype because authentication/user accounts are not part of the current scope. Add authentication and user-scoped favorites before public multi-user deployment.

## Security notes
- Keep `.env` private and never expose provider keys in browser code.
- AI endpoint has request-size limits, input validation, rate limiting, timeouts, and output-schema validation.
- Use HTTPS and configure production CORS/CSP and a managed database before public deployment.
