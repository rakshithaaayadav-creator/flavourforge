const test = require('node:test');
const assert = require('node:assert/strict');
const { validateFavoriteId, validateAiRequest, validateGeneratedRecipe } = require('./validation');

test('favorite ids must be positive known recipe ids', () => {
  const ids = new Set([1, 2, 7]);
  assert.equal(validateFavoriteId('2', ids), 2);
  assert.equal(validateFavoriteId('99', ids), null);
  assert.equal(validateFavoriteId('../1', ids), null);
});

test('AI request validation rejects oversized and malformed input', () => {
  assert.deepEqual(validateAiRequest({ items: ['Egg'], mood: 'Quick 15-Minute Skillet Meal', diet: 'No Restrictions' }),
    { items: ['Egg'], mood: 'Quick 15-Minute Skillet Meal', diet: 'No Restrictions' });
  assert.equal(validateAiRequest({ items: ['x'.repeat(51)], mood: 'Quick 15-Minute Skillet Meal', diet: 'No Restrictions' }), null);
  assert.equal(validateAiRequest({ items: [], mood: 'unknown', diet: 'any' }), null);
});

test('AI output schema is validated before returning to the browser', () => {
  const valid = { title: 'Egg toast', ingredients: ['2 eggs'], steps: ['Mix', 'Cook'], chefTip: 'Serve warm' };
  assert.equal(validateGeneratedRecipe(valid), true);
  assert.equal(validateGeneratedRecipe({ ...valid, steps: [] }), false);
  assert.equal(validateGeneratedRecipe({ ...valid, title: '<script>' }), true); // rendered as text by output layer
});
