const ALLOWED_MOODS = new Set(['Quick 15-Minute Skillet Meal', 'Cozy Comfort Bowl / Soup', 'Crispy Street-Style Snack', 'High-Protein College Dorm Hack']);
const ALLOWED_DIETS = new Set(['No Restrictions', 'Vegetarian Only', 'High Protein & Low Carb']);

function validateFavoriteId(value, validRecipeIds) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 && validRecipeIds.has(id) ? id : null;
}

function validateAiRequest(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const items = Array.isArray(body.items) ? body.items : [];
  if (items.length > 30) return null;
  if (items.some(item => typeof item !== 'string')) return null;
  const cleanItems = items.map(item => item.trim()).filter(Boolean);
  if (cleanItems.length !== items.length || cleanItems.some(item => item.length > 50)) return null;
  const mood = String(body.mood || 'Quick 15-Minute Skillet Meal').slice(0, 40);
  const diet = String(body.diet || 'No Restrictions').slice(0, 40);
  if (!ALLOWED_MOODS.has(mood) || !ALLOWED_DIETS.has(diet)) return null;
  return { items: cleanItems, mood, diet };
}

function validateGeneratedRecipe(recipe) {
  return !!recipe &&
    typeof recipe.title === 'string' && recipe.title.length > 0 && recipe.title.length <= 120 &&
    Array.isArray(recipe.ingredients) && recipe.ingredients.length <= 30 &&
    recipe.ingredients.every(item => typeof item === 'string' && item.length <= 200) &&
    Array.isArray(recipe.steps) && recipe.steps.length >= 1 && recipe.steps.length <= 10 &&
    recipe.steps.every(step => typeof step === 'string' && step.length <= 500) &&
    typeof recipe.chefTip === 'string' && recipe.chefTip.length <= 500;
}

module.exports = { validateFavoriteId, validateAiRequest, validateGeneratedRecipe };
