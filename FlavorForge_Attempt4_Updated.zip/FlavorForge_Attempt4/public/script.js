/**
     * 4. CURATED DISH PHOTOGRAPHY & FALLBACK HANDLER
     * High-resolution food photography matched closely to each specific dish,
     * with automatic category/stylized fallback on network error.
     */
    const FALLBACK_FOOD_PHOTOS = [
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80"
    ];

    function handleImageError(imgEl, titleText) {
      if (!imgEl.dataset.fallbackTried) {
        imgEl.dataset.fallbackTried = "1";
        imgEl.src = FALLBACK_FOOD_PHOTOS[0];
      } else {
        const label = encodeURIComponent((titleText || 'FlavorForge Dish').slice(0, 26));
        imgEl.onerror = null;
        imgEl.src = `https://placehold.co/800x500/D95D39/FAF7F2?text=${label}`;
      }
    }

    /**
     * 4B. RICH EMBEDDED DATABASE OF 40 HOME-STYLE RECIPES (WITH CURATED PHOTOS)
     * Carefully calibrated so:
     * - Eggs + Potatoes + Onions -> Aloo Egg Bhurji (100%), Spanish Omelette (75% - missing butter)
     * - Egg + Onion + Bread -> Classic Masala Egg Toast (100%)
     * - Assumed staples (Salt, Oil, Water, Turmeric, Chili Powder, Pepper) are excluded from denominator.
     */
    let RECIPES_DB = [];

    /**
     * 5. APPLICATION STATE
     */
    let selectedPantry = new Set();      // Canonical ingredient names
    let expiringItems = new Set();       // Canonical names flagged as expiring soon
    let savedRecipeIds = new Set();

    async function loadSavedFavorites() {
      try {
        const response = await fetch('/api/favorites');
        if (!response.ok) throw new Error(`Favorites request failed (${response.status})`);
        const data = await response.json();
        savedRecipeIds = new Set(Array.isArray(data.favorites) ? data.favorites : []);
      } catch (error) {
        FlavorForgeUtils.log('error', 'favorites_api_load_failed', { message: error.message });
        showToast('Saved recipes could not be loaded. Start the FlavorForge server and refresh.', 'warn');
      }
      updateSavedBadge();
      renderRecipes();
      renderSavedView();
    }
    let activeFilter = 'all';
    let currentModalRecipe = null;
    let currentModalServings = 2;
    let voiceStepIndex = -1;
    let isVoicePlaying = false;

    /**
     * 6. DECIMAL-TO-FRACTION CULINARY FORMATTER
     * Converts decimal quantities (e.g., 1.5 -> "1 1/2", 0.25 -> "1/4", 0.33 -> "1/3") cleanly.
     */
    function formatCulinaryQuantity(num) {
      if (!num || num <= 0) return '';
      const whole = Math.floor(num);
      const remainder = num - whole;
      
      const fractions = [
        { val: 0, str: '' },
        { val: 0.125, str: '1/8' },
        { val: 0.25, str: '1/4' },
        { val: 0.333, str: '1/3' },
        { val: 0.5, str: '1/2' },
        { val: 0.666, str: '2/3' },
        { val: 0.75, str: '3/4' },
        { val: 1, str: '' }
      ];

      let closest = fractions[0];
      let minDiff = Math.abs(remainder - closest.val);
      for (const f of fractions) {
        const diff = Math.abs(remainder - f.val);
        if (diff < minDiff) {
          minDiff = diff;
          closest = f;
        }
      }

      if (closest.val === 1) {
        return `${whole + 1}`;
      }
      if (whole === 0 && closest.str) {
        return closest.str;
      }
      if (whole > 0 && closest.str) {
        return `${whole} ${closest.str}`;
      }
      return `${whole}`;
    }

    /**
     * 7. TOAST NOTIFICATION SYSTEM (No alert() used anywhere)
     */
    function showToast(message, type = 'info') {
      const container = document.getElementById('toast-container');
      const toast = document.createElement('div');
      const colors = {
        info: 'bg-charcoal text-white border-stone-700',
        success: 'bg-sage-700 text-white border-sage-600',
        warn: 'bg-amber-600 text-white border-amber-500'
      };
      toast.className = `pointer-events-auto px-4 py-3 rounded-xl shadow-lg border text-xs sm:text-sm font-medium flex items-center justify-between gap-3 transition-all transform translate-y-2 opacity-0 ${colors[type] || colors.info}`;
      const messageNode = document.createElement('span');
      messageNode.textContent = String(message ?? '');
      toast.appendChild(messageNode);
      container.appendChild(toast);

      requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
      });

      setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
      }, 2800);
    }

    /**
     * 8. PANTRY SELECTION & EXPIRY TRACKER LOGIC
     */
    function toggleIngredient(canonical) {
      const norm = normalizeIngredient(canonical);
      if (selectedPantry.has(norm)) {
        selectedPantry.delete(norm);
        expiringItems.delete(norm);
      } else {
        selectedPantry.add(norm);
      }
      syncUI();
    }

    function toggleExpiringFlag(canonical, event) {
      if (event) event.stopPropagation();
      if (expiringItems.has(canonical)) {
        expiringItems.delete(canonical);
        showToast(`Removed expiry flag from ${formatDisplayName(canonical)}`, 'info');
      } else {
        expiringItems.add(canonical);
        showToast(`⏰ Prioritizing recipes using ${formatDisplayName(canonical)}!`, 'warn');
      }
      syncUI();
    }

    function loadDemoPreset(presetName) {
      selectedPantry.clear();
      expiringItems.clear();
      if (presetName === 'eggs_potato_onion') {
        ['egg', 'potato', 'onion'].forEach(i => selectedPantry.add(i));
        showToast('Loaded Demo Fridge: Eggs, Potatoes & Onions!', 'success');
      } else if (presetName === 'egg_onion_bread') {
        ['egg', 'onion', 'bread'].forEach(i => selectedPantry.add(i));
        showToast('Loaded Toast Trio: Egg, Onion & Bread!', 'success');
      }
      syncUI();
    }

    function clearPantry() {
      selectedPantry.clear();
      expiringItems.clear();
      syncUI();
      showToast('Pantry basket cleared.', 'info');
    }

    function handleCustomIngredientAdd() {
      const input = document.getElementById('custom-ingredient-input');
      const val = input.value.trim();
      if (!val) return;
      const canonical = normalizeIngredient(val);
      selectedPantry.add(canonical);
      input.value = '';
      document.getElementById('autocomplete-list').classList.add('hidden');
      syncUI();
      showToast(`Added "${formatDisplayName(canonical)}" to your fridge`, 'success');
    }

    function setupAutocomplete() {
      const input = document.getElementById('custom-ingredient-input');
      const dropdown = document.getElementById('autocomplete-list');
      const allKnown = Array.from(new Set(Object.values(SYNONYM_MAP)));

      input.addEventListener('input', () => {
        const q = input.value.trim().toLowerCase();
        if (!q) {
          dropdown.classList.add('hidden');
          return;
        }
        // Match both canonical names and raw synonym keys
        const matchedCanonicals = new Set();
        Object.entries(SYNONYM_MAP).forEach(([syn, canon]) => {
          if (syn.includes(q) || canon.includes(q)) {
            matchedCanonicals.add(canon);
          }
        });

        if (matchedCanonicals.size === 0) {
          dropdown.classList.add('hidden');
          return;
        }

        dropdown.innerHTML = Array.from(matchedCanonicals).slice(0, 7).map(canon => `
          <button type="button" onclick="selectAutocomplete('${canon}')" class="w-full text-left px-3.5 py-2 text-xs sm:text-sm hover:bg-terracotta-50 flex items-center justify-between border-b border-stone-100 last:border-0 cursor-pointer">
            <span class="font-medium text-charcoal">${formatDisplayName(canon)}</span>
            <span class="text-[11px] text-stone-400">${selectedPantry.has(canon) ? '✓ Selected' : '+ Add'}</span>
          </button>
        `).join('');
        dropdown.classList.remove('hidden');
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleCustomIngredientAdd();
        }
      });

      document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !dropdown.contains(e.target)) {
          dropdown.classList.add('hidden');
        }
      });
    }

    function selectAutocomplete(canon) {
      selectedPantry.add(canon);
      document.getElementById('custom-ingredient-input').value = '';
      document.getElementById('autocomplete-list').classList.add('hidden');
      syncUI();
      showToast(`Added "${formatDisplayName(canon)}"`, 'success');
    }

    /**
     * 9. RENDER PANTRY CATEGORIES & SELECTED BASKET
     */
    function renderPantryUI() {
      // Render Selected Basket
      const basketEl = document.getElementById('selected-basket');
      document.getElementById('selected-count').textContent = selectedPantry.size;

      if (selectedPantry.size === 0) {
        basketEl.innerHTML = `<span class="text-xs text-stone-400 italic">No ingredients selected yet. Tap staples below!</span>`;
      } else {
        basketEl.innerHTML = Array.from(selectedPantry).map(canon => {
          const isExpiring = expiringItems.has(canon);
          return `
            <div class="inline-flex items-center gap-1.5 pl-2.5 pr-1.5 py-1 rounded-full text-xs font-semibold border transition ${
              isExpiring 
                ? 'bg-amber-100 border-amber-400 text-amber-900 shadow-2xs' 
                : 'bg-sage-100 border-sage-300 text-sage-800'
            }">
              <span>${formatDisplayName(canon)}</span>
              <button 
                onclick="toggleExpiringFlag('${canon}', event)" 
                title="${isExpiring ? 'Marked Expiring Soon (Click to unmark)' : 'Mark as Expiring Soon'}"
                class="w-5 h-5 rounded-full flex items-center justify-center text-[11px] transition cursor-pointer ${
                  isExpiring ? 'bg-amber-500 text-white' : 'hover:bg-sage-200 text-sage-700'
                }">
                ⏰
              </button>
              <button onclick="toggleIngredient('${canon}')" title="Remove" class="w-5 h-5 rounded-full hover:bg-black/10 flex items-center justify-center text-xs cursor-pointer">
                ×
              </button>
            </div>
          `;
        }).join('');
      }

      // Render Categorized Quick-Tap Pills
      const catContainer = document.getElementById('pantry-categories');
      catContainer.innerHTML = PANTRY_CATALOG.map(group => `
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2 flex items-center gap-1.5">
            <span>${group.icon}</span>
            <span>${group.category}</span>
          </h3>
          <div class="flex flex-wrap gap-1.5">
            ${group.items.map(canon => {
              const isSelected = selectedPantry.has(canon);
              return `
                <button 
                  onclick="toggleIngredient('${canon}')"
                  class="px-2.5 py-1.5 rounded-xl text-xs font-medium border transition cursor-pointer ${
                    isSelected 
                      ? 'bg-terracotta-500 text-white border-terracotta-600 shadow-2xs font-semibold' 
                      : 'bg-cream hover:bg-sand text-stone-700 border-stone-200/90'
                  }">
                  ${isSelected ? '✓ ' : ''}${formatDisplayName(canon)}
                </button>
              `;
            }).join('')}
          </div>
        </div>
      `).join('');

      // Sync AI Chef pantry preview if open
      const aiPreview = document.getElementById('ai-pantry-preview');
      if (aiPreview) {
        if (selectedPantry.size === 0) {
          aiPreview.innerHTML = `<span class="text-xs text-stone-400 italic">Your fridge basket is empty — select items in Rescue Matches or we'll use mystery pantry staples!</span>`;
        } else {
          aiPreview.innerHTML = Array.from(selectedPantry).map(canon => `
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-sage-100 text-sage-800 border border-sage-200">
              ${expiringItems.has(canon) ? '⏰ ' : ''}${formatDisplayName(canon)}
            </span>
          `).join('');
        }
      }
    }

    /**
     * 10. SET-INTERSECTION MATCH SCORING ALGORITHM
     * Calculates MatchPercentage = Math.round((|UserPantry ∩ RecipeCoreIngredients| / |RecipeCoreIngredients|) * 100)
     */
    function evaluateRecipe(recipe) {
      return FlavorForgeRecipeEngine.evaluateRecipeMatch(recipe, selectedPantry, expiringItems);
    }

    /**
     * 11. FILTERING, SORTING & RENDERING RECIPE CARDS
     */
    function setFilter(filterKey) {
      activeFilter = filterKey;
      document.querySelectorAll('.filter-pill').forEach(btn => {
        if (btn.dataset.filter === filterKey) {
          btn.className = 'filter-pill px-3 py-1.5 rounded-xl text-xs font-semibold bg-charcoal text-white transition cursor-pointer';
        } else {
          btn.className = 'filter-pill px-3 py-1.5 rounded-xl text-xs font-semibold bg-sand/80 text-stone-700 hover:bg-sand transition cursor-pointer';
        }
      });
      renderRecipes();
    }

    function renderRecipes() {
      const sortMode = document.getElementById('sort-select').value;
      const evaluated = RECIPES_DB.map(evaluateRecipe);

      // Update Filter Counts
      document.getElementById('count-all').textContent = evaluated.length;
      document.getElementById('count-ready').textContent = evaluated.filter(r => r.matchPct === 100).length;

      // Apply Active Filter
      let filtered = evaluated.filter(r => {
        if (activeFilter === 'ready') return r.matchPct === 100;
        if (activeFilter === 'quick') return r.prepTime <= 20;
        if (activeFilter === 'veg') return r.isVeg;
        return true;
      });

      // Sort Results
      filtered.sort((a, b) => {
        if (sortMode === 'time') return a.prepTime - b.prepTime;
        if (sortMode === 'calories') return a.calories - b.calories;
        // Default: Best Match %, boosted by Expiring Item Rescue & fewer missing items
        if (b.matchPct !== a.matchPct) return b.matchPct - a.matchPct;
        if (b.expiringRescueCount !== a.expiringRescueCount) return b.expiringRescueCount - a.expiringRescueCount;
        return a.missing.length - b.missing.length;
      });

      // Update Match Banner
      const bannerText = document.getElementById('match-banner-text');
      const expiryPill = document.getElementById('expiry-banner-pill');
      expiryPill.classList.toggle('hidden', expiringItems.size === 0);

      if (selectedPantry.size === 0) {
        bannerText.innerHTML = `Showing <strong>${filtered.length}</strong> home-style recipes. Tap ingredients on the left to calculate instant match scores!`;
      } else {
        const readyCount = evaluated.filter(r => r.matchPct === 100).length;
        const closeCount = evaluated.filter(r => r.matchPct >= 66 && r.matchPct < 100).length;
        bannerText.innerHTML = `Found <strong>${readyCount}</strong> 100% ready-to-cook recipes and <strong>${closeCount}</strong> close matches using your <strong>${selectedPantry.size}</strong> items.`;
      }

      const grid = document.getElementById('recipes-grid');
      if (filtered.length === 0) {
        grid.innerHTML = `
          <div class="col-span-full bg-white rounded-2xl border border-stone-200 p-10 text-center">
            <div class="text-4xl mb-2">🥗</div>
            <h3 class="font-display font-bold text-lg text-charcoal">No recipes match this exact filter</h3>
            <p class="text-xs sm:text-sm text-stone-500 mt-1 mb-4">Try switching back to "All Recipes" or adding 1-2 more staples to your fridge basket.</p>
            <button onclick="setFilter('all')" class="px-4 py-2 rounded-xl bg-terracotta-500 text-white text-xs font-semibold hover:bg-terracotta-600 transition">
              Show All Recipes
            </button>
          </div>
        `;
        return;
      }

      grid.innerHTML = filtered.map(recipe => createRecipeCardHTML(recipe)).join('');
    }

    function createRecipeCardHTML(recipe) {
      const isSaved = savedRecipeIds.has(recipe.id);
      let badgeStyle = 'bg-white/95 text-stone-700 border-stone-200/80 backdrop-blur-xs';
      let badgeLabel = `${recipe.matchPct}% Match`;

      if (selectedPantry.size > 0) {
        if (recipe.matchPct === 100) {
          badgeStyle = 'bg-sage-600/95 text-white border-sage-700 shadow-sm backdrop-blur-xs';
          badgeLabel = '100% Match • Ready!';
        } else if (recipe.matchPct >= 70) {
          badgeStyle = 'bg-amber-100/95 text-amber-900 border-amber-300 shadow-sm backdrop-blur-xs';
          badgeLabel = `${recipe.matchPct}% Match • Missing ${recipe.missing.length}`;
        } else if (recipe.matchPct > 0) {
          badgeStyle = 'bg-white/95 text-terracotta-700 border-terracotta-200 shadow-sm backdrop-blur-xs';
          badgeLabel = `${recipe.matchPct}% Match`;
        }
      }

      const safeTitle = recipe.title.replace(/'/g, "\\'");

      return `
        <article onclick="openRecipeModal(${recipe.id})" class="group bg-white rounded-2xl border border-stone-200/90 hover:border-terracotta-400 shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between cursor-pointer">
          <div>
            <!-- Dish Photo Header (16:10 / 180px tall with smooth hover zoom & overlaid badges) -->
            <div class="relative h-44 sm:h-48 w-full bg-stone-200 overflow-hidden">
              <img 
                src="${recipe.image}" 
                alt="${recipe.title}" 
                loading="lazy"
                onerror="handleImageError(this, '${safeTitle}')"
                class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
              />
              <!-- Subtle Top & Bottom Gradient Scrim for Badge Contrast -->
              <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-black/25 pointer-events-none"></div>

              <!-- Top Overlay Row: Match Badge, Rescue Priority & Bookmark Heart -->
              <div class="absolute top-3 left-3 right-3 flex items-start justify-between gap-2">
                <div class="flex flex-wrap items-center gap-1.5">
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold border ${badgeStyle}">
                    ${badgeLabel}
                  </span>
                  ${recipe.expiringRescueCount > 0 ? `
                    <span class="px-2 py-1 rounded-full text-[11px] font-bold bg-amber-500 text-white shadow-sm flex items-center gap-1">
                      🔥 Rescue Priority
                    </span>
                  ` : ''}
                </div>
                <button 
                  onclick="toggleFavoriteById(${recipe.id}, event)" 
                  class="w-8 h-8 rounded-full bg-white/90 hover:bg-white shadow-sm backdrop-blur-xs flex items-center justify-center text-base transition shrink-0 cursor-pointer"
                  title="${isSaved ? 'Remove from Saved' : 'Save Recipe'}">
                  ${isSaved ? '❤️' : '🤍'}
                </button>
              </div>

              <!-- Bottom Overlay Row: Category & Veg/Non-Veg Pill -->
              <div class="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-white text-[11px] font-semibold">
                <span class="px-2 py-0.5 rounded-md bg-black/45 backdrop-blur-xs uppercase tracking-wider text-amber-200">
                  ${recipe.category}
                </span>
                <span class="px-2 py-0.5 rounded-md bg-black/45 backdrop-blur-xs">
                  ${recipe.isVeg ? '🟢 Veg' : '🔴 Egg/Non-Veg'}
                </span>
              </div>
            </div>

            <!-- Card Content Body -->
            <div class="p-5 pb-3">
              <h3 class="font-display font-bold text-lg text-charcoal group-hover:text-terracotta-600 transition leading-snug mb-2">
                ${recipe.title}
              </h3>

              <!-- Metadata Bar -->
              <div class="flex flex-wrap items-center gap-2.5 text-xs text-stone-500 mb-3.5 pb-3 border-b border-stone-100">
                <span>⏱️ ${recipe.prepTime} mins</span>
                <span>•</span>
                <span>${recipe.difficulty}</span>
                <span>•</span>
                <span>🔥 ${recipe.calories} kcal</span>
              </div>

              <!-- Ingredient Overlap & Missing Pills -->
              <div class="space-y-2">
                ${recipe.matched.length > 0 ? `
                  <div class="flex flex-wrap items-center gap-1">
                    <span class="text-[11px] font-semibold text-sage-700 mr-1">Have:</span>
                    ${recipe.matched.map(m => `
                      <span class="px-2 py-0.5 rounded-md text-[11px] font-medium bg-sage-50 text-sage-800 border border-sage-200">
                        ✓ ${formatDisplayName(m.canonical)}
                      </span>
                    `).join('')}
                  </div>
                ` : ''}

                ${recipe.missing.length > 0 ? `
                  <div class="flex flex-wrap items-center gap-1">
                    <span class="text-[11px] font-semibold text-amber-800 mr-1">${selectedPantry.size > 0 ? 'Missing:' : 'Core Items:'}</span>
                    ${recipe.missing.map(m => {
                      const hasSub = Boolean(SUBSTITUTION_MATRIX[m.canonical]);
                      return `
                        <span class="px-2 py-0.5 rounded-md text-[11px] font-medium ${
                          selectedPantry.size > 0 
                            ? 'bg-amber-50 text-amber-900 border border-amber-200' 
                            : 'bg-cream text-stone-700 border border-stone-200'
                        }" title="${hasSub ? 'Swap: ' + SUBSTITUTION_MATRIX[m.canonical] : ''}">
                          ${formatDisplayName(m.canonical)}${hasSub && selectedPantry.size > 0 ? ' 💡' : ''}
                        </span>
                      `;
                    }).join('')}
                  </div>
                ` : ''}
              </div>
            </div>
          </div>

          <!-- Card Footer Action -->
          <div class="px-5 py-3 bg-cream/50 border-t border-stone-100 flex items-center justify-between text-xs font-semibold text-terracotta-600 group-hover:text-terracotta-700">
            <span>${recipe.missing.length > 0 && selectedPantry.size > 0 ? 'View Substitutions & Steps' : 'Start Cooking Walkthrough'}</span>
            <span class="transform group-hover:translate-x-1 transition">→</span>
          </div>
        </article>
      `;
    }

    /**
     * 12. RECIPE DETAIL MODAL, SERVING SCALER & SUBSTITUTIONS
     */
    function openRecipeModal(recipeId) {
      const rawRecipe = RECIPES_DB.find(r => r.id === recipeId);
      if (!rawRecipe) return;

      stopVoiceGuide();
      currentModalRecipe = evaluateRecipe(rawRecipe);
      currentModalServings = rawRecipe.baseServings;

      renderModalContent();
      document.getElementById('recipe-modal').classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }

    function closeRecipeModal() {
      stopVoiceGuide();
      document.getElementById('recipe-modal').classList.add('hidden');
      document.body.style.overflow = '';
      currentModalRecipe = null;
    }

    function changeServings(delta) {
      if (!currentModalRecipe) return;
      const next = currentModalServings + delta;
      if (next < 1 || next > 12) return;
      currentModalServings = next;
      renderModalContent();
    }

    function renderModalContent() {
      const r = currentModalRecipe;
      if (!r) return;

      const scaleFactor = currentModalServings / r.baseServings;
      const isSaved = savedRecipeIds.has(r.id);

      const heroImg = document.getElementById('modal-hero-img');
      heroImg.dataset.fallbackTried = "";
      heroImg.onerror = () => handleImageError(heroImg, r.title);
      heroImg.src = r.image || FALLBACK_FOOD_PHOTOS[0];
      heroImg.alt = r.title;

      document.getElementById('modal-title').textContent = r.title;
      document.getElementById('modal-save-icon').textContent = isSaved ? '❤️' : '🤍';
      document.getElementById('modal-time').textContent = `${r.prepTime} mins`;
      document.getElementById('modal-difficulty').textContent = r.difficulty;
      document.getElementById('modal-servings').textContent = currentModalServings;
      document.getElementById('modal-diet-tag').innerHTML = r.isVeg 
        ? `<span class="font-semibold text-sage-700">🟢 Vegetarian</span>` 
        : `<span class="font-semibold text-terracotta-700">🔴 Egg / Non-Veg</span>`;

      // Badges overlaid on Hero Banner
      document.getElementById('modal-badges').innerHTML = `
        <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-terracotta-500 text-white shadow-xs">${r.category}</span>
        ${selectedPantry.size > 0 ? `<span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sage-600 text-white shadow-xs">${r.matchPct}% Fridge Match</span>` : ''}
      `;

      // Nutrition (Per Serving)
      document.getElementById('nut-cal').textContent = r.calories;
      document.getElementById('nut-pro').textContent = `${r.protein}g`;
      document.getElementById('nut-carb').textContent = `${r.carbs}g`;
      document.getElementById('nut-fat').textContent = `${r.fats}g`;

      // Smart Substitutions Box
      const subBox = document.getElementById('modal-substitutions-box');
      const subList = document.getElementById('modal-substitutions-list');
      const missingWithSubs = r.missing.filter(m => SUBSTITUTION_MATRIX[m.canonical]);

      if (selectedPantry.size > 0 && r.missing.length > 0) {
        subBox.classList.remove('hidden');
        subList.innerHTML = r.missing.map(m => {
          const tip = SUBSTITUTION_MATRIX[m.canonical] || `Check pantry for similar veggies or spices.`;
          return `
            <li class="flex items-start gap-2">
              <span class="font-bold text-amber-800 shrink-0">• No ${formatDisplayName(m.canonical)}?</span>
              <span>${tip}</span>
            </li>
          `;
        }).join('');
      } else {
        subBox.classList.add('hidden');
      }

      // Scaled Ingredients List
      const ingList = document.getElementById('modal-ingredients-list');
      ingList.innerHTML = r.coreIngredients.map(item => {
        const scaledQty = formatCulinaryQuantity(item.qty * scaleFactor);
        const haveIt = selectedPantry.has(item.canonical);
        return `
          <div class="flex items-center justify-between p-2.5 rounded-xl border ${
            haveIt ? 'bg-sage-50/70 border-sage-200' : 'bg-cream border-stone-200/80'
          }">
            <div class="flex items-center gap-2">
              <span class="text-xs">${haveIt ? '✅' : '🔸'}</span>
              <span class="text-xs sm:text-sm font-medium text-charcoal">${item.name}</span>
            </div>
            <span class="text-xs sm:text-sm font-bold text-terracotta-700 bg-white px-2.5 py-0.5 rounded-lg border border-stone-200/70 shrink-0">
              ${scaledQty} ${item.unit}
            </span>
          </div>
        `;
      }).join('');

      document.getElementById('modal-staples-note').innerHTML = `
        <strong>Assumed Pantry Staples:</strong> ${r.assumedStaples.join(', ')}
      `;

      // Cooking Steps
      const stepsList = document.getElementById('modal-steps-list');
      stepsList.innerHTML = r.steps.map((step, idx) => `
        <li id="recipe-step-${idx}" class="p-3.5 rounded-2xl bg-cream border border-stone-200/80 flex gap-3 items-start transition-all">
          <span class="w-6 h-6 rounded-full bg-charcoal text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
            ${idx + 1}
          </span>
          <p class="text-xs sm:text-sm text-stone-800 leading-relaxed">${step}</p>
        </li>
      `).join('');
    }

    /**
     * 13. VOICE-GUIDED HANDS-FREE COOKING MODE (Web Speech API)
     */
    function startVoiceGuide() {
      if (!('speechSynthesis' in window)) {
        showToast('Voice synthesis is not supported in this browser.', 'warn');
        return;
      }
      if (!currentModalRecipe) return;
      window.speechSynthesis.cancel();
      isVoicePlaying = true;
      voiceStepIndex = 0;
      updateVoiceButtons();
      speakCurrentStep();
    }

    function speakCurrentStep() {
      if (!currentModalRecipe || voiceStepIndex < 0 || voiceStepIndex >= currentModalRecipe.steps.length) {
        stopVoiceGuide();
        return;
      }

      // Highlight active step visually
      currentModalRecipe.steps.forEach((_, idx) => {
        const el = document.getElementById(`recipe-step-${idx}`);
        if (el) {
          el.classList.toggle('active-voice-step', idx === voiceStepIndex);
        }
      });

      const activeEl = document.getElementById(`recipe-step-${voiceStepIndex}`);
      if (activeEl) activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      const textToRead = `Step ${voiceStepIndex + 1}. ${currentModalRecipe.steps[voiceStepIndex]}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.96;
      utterance.onend = () => {
        if (isVoicePlaying && voiceStepIndex < currentModalRecipe.steps.length - 1) {
          voiceStepIndex++;
          setTimeout(() => {
            if (isVoicePlaying) speakCurrentStep();
          }, 900);
        } else {
          stopVoiceGuide();
        }
      };
      window.speechSynthesis.speak(utterance);
    }

    function nextVoiceStep() {
      if (!currentModalRecipe) return;
      window.speechSynthesis.cancel();
      if (voiceStepIndex < currentModalRecipe.steps.length - 1) {
        voiceStepIndex++;
        speakCurrentStep();
      } else {
        stopVoiceGuide();
      }
    }

    function stopVoiceGuide() {
      isVoicePlaying = false;
      voiceStepIndex = -1;
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      document.querySelectorAll('[id^="recipe-step-"]').forEach(el => el.classList.remove('active-voice-step'));
      updateVoiceButtons();
    }

    function updateVoiceButtons() {
      const playBtn = document.getElementById('voice-play-btn');
      const nextBtn = document.getElementById('voice-next-btn');
      const stopBtn = document.getElementById('voice-stop-btn');
      if (isVoicePlaying) {
        playBtn.classList.add('hidden');
        nextBtn.classList.remove('hidden');
        stopBtn.classList.remove('hidden');
      } else {
        playBtn.classList.remove('hidden');
        nextBtn.classList.add('hidden');
        stopBtn.classList.add('hidden');
      }
    }

    /**
     * 14. FAVORITE RECIPES BOOKMARKING (localStorage)
     */
    async function toggleFavoriteById(recipeId, event) {
      if (event) event.stopPropagation();
      if (!Number.isInteger(recipeId) || recipeId <= 0) {
        showToast('Invalid recipe selection.', 'warn');
        return;
      }
      const wasSaved = savedRecipeIds.has(recipeId);
      try {
        const response = await fetch(`/api/favorites/${recipeId}`, {
          method: wasSaved ? 'DELETE' : 'PUT',
          headers: { 'Content-Type': 'application/json' }
        });
        if (!response.ok) throw new Error(`Favorites update failed (${response.status})`);
        if (wasSaved) {
          savedRecipeIds.delete(recipeId);
          showToast('Removed from Saved Recipes', 'info');
        } else {
          savedRecipeIds.add(recipeId);
          showToast('Saved to My Rescue Recipes ❤️', 'success');
        }
        updateSavedBadge();
        renderRecipes();
        renderSavedView();
      } catch (error) {
        FlavorForgeUtils.log('error', 'favorites_api_write_failed', { recipeId, message: error.message });
        showToast('Could not update saved recipes. Please try again.', 'warn');
      }
    }

    function toggleFavoriteCurrent() {
      if (!currentModalRecipe) return;
      toggleFavoriteById(currentModalRecipe.id);
      document.getElementById('modal-save-icon').textContent = savedRecipeIds.has(currentModalRecipe.id) ? '❤️' : '🤍';
    }

    function updateSavedBadge() {
      document.getElementById('saved-count-badge').textContent = savedRecipeIds.size;
    }

    function renderSavedView() {
      const grid = document.getElementById('saved-recipes-grid');
      const savedList = RECIPES_DB.filter(r => savedRecipeIds.has(r.id)).map(evaluateRecipe);

      if (savedList.length === 0) {
        grid.innerHTML = `
          <div class="col-span-full bg-white rounded-2xl border border-stone-200 p-12 text-center">
            <div class="text-4xl mb-2">🔖</div>
            <h3 class="font-display font-bold text-lg text-charcoal">No saved recipes yet</h3>
            <p class="text-xs sm:text-sm text-stone-500 mt-1 mb-4">Tap the heart icon on any recipe card to keep it handy for quick weeknight cooking.</p>
            <button onclick="switchView('discover')" class="px-4 py-2 rounded-xl bg-terracotta-500 text-white text-xs font-semibold hover:bg-terracotta-600 transition">
              Browse Rescue Matches
            </button>
          </div>
        `;
        return;
      }

      grid.innerHTML = savedList.map(r => createRecipeCardHTML(r)).join('');
    }

    /**
     * 15. VIEW NAVIGATION
     */
    function switchView(viewName) {
      ['discover', 'ai', 'saved'].forEach(v => {
        document.getElementById(`view-${v}`).classList.toggle('hidden', v !== viewName);
        const tabBtn = document.getElementById(`tab-${v}`);
        if (v === viewName) {
          tabBtn.className = 'px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all bg-white text-charcoal shadow-xs flex items-center gap-1.5';
        } else {
          tabBtn.className = 'px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all text-stone-600 hover:text-charcoal flex items-center gap-1.5';
        }
      });

      if (viewName === 'saved') renderSavedView();
      if (viewName === 'ai') renderPantryUI();
    }

    /**
     * 16. AI CHEF IMPROVISER (Gemini API + Intelligent Culinary Synthesis Fallback)
     */
    async function generateAIChefRecipe() {
      const btn = document.getElementById('generate-ai-btn');
      const output = document.getElementById('ai-recipe-output');
      const mood = document.getElementById('ai-mood-select').value;
      const diet = document.getElementById('ai-diet-select').value;

      const items = selectedPantry.size > 0
        ? Array.from(selectedPantry).map(formatDisplayName)
        : ['Eggs', 'Onions', 'Potatoes', 'Bread'];

      btn.disabled = true;
      btn.innerHTML = `<span class="animate-spin">⏳</span><span>Chef is improvising with your ingredients...</span>`;
      output.classList.remove('hidden');
      output.innerHTML = `
        <div class="p-6 rounded-2xl bg-cream border border-stone-200 animate-pulse space-y-3">
          <div class="h-5 bg-stone-200 rounded w-1/2"></div>
          <div class="h-4 bg-stone-200 rounded w-3/4"></div>
          <div class="h-24 bg-stone-200 rounded"></div>
        </div>
      `;

      const prompt = `You are a creative zero-waste chef. Invent ONE practical, safe, delicious home-style recipe using ONLY these available fridge ingredients: ${items.join(', ')} (plus basic pantry staples like salt, oil, water, pepper, chili powder). Style: ${mood}. Diet: ${diet}. Return clean JSON with keys: "title", "prepTimeMins" (number), "calories" (number), "ingredients" (array of strings with measurements), "steps" (array of 4-5 clear step strings), "chefTip" (string).`;

      let generated = null;
      let aiFallbackReason = 'server_unavailable';

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 18000);
        try {
          const response = await fetch('/api/ai/recipe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({ items, mood, diet })
          });
          if (!response.ok) {
            aiFallbackReason = response.status === 503 ? 'ai_provider_not_configured' : 'ai_server_error';
            FlavorForgeUtils.log('warn', 'ai_server_request_failed', { status: response.status });
          } else {
            const data = await response.json();
            generated = data.recipe || null;
          }
        } finally {
          clearTimeout(timeoutId);
        }
      } catch (err) {
        aiFallbackReason = err.name === 'AbortError' ? 'request_timeout' : 'network_or_request_error';
        FlavorForgeUtils.log('warn', 'ai_generation_request_failed', { reason: aiFallbackReason, name: err.name, message: err.message });
      }

      if (generated && (
        typeof generated.title !== 'string' ||
        !Array.isArray(generated.ingredients) ||
        !Array.isArray(generated.steps) ||
        typeof generated.chefTip !== 'string'
      )) {
        aiFallbackReason = 'invalid_response_schema';
        FlavorForgeUtils.log('warn', 'ai_response_schema_invalid', { reason: aiFallbackReason });
        generated = null;
      }

      if (!generated) {
        FlavorForgeUtils.log('info', 'ai_deterministic_fallback_used', { reason: aiFallbackReason, ingredientCount: items.length, mood, diet });
        // Smart deterministic culinary generator tailored to the user's exact basket
        await new Promise(r => setTimeout(r, 650));
        generated = buildSmartFallbackRecipe(items, mood, diet);
      }

      const aiPhotoMap = {
        'Quick 15-Minute Skillet Meal': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=900&q=80',
        'Cozy Comfort Bowl / Soup': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=900&q=80',
        'Crispy Street-Style Snack': 'https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=900&q=80',
        'High-Protein College Dorm Hack': 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=80'
      };
      const aiDishPhoto = aiPhotoMap[mood] || FALLBACK_FOOD_PHOTOS[1];
      const safeAiTitle = generated.title.replace(/'/g, "\\'");

      output.innerHTML = `
        <div class="rounded-2xl bg-gradient-to-br from-cream to-sand/60 border border-terracotta-200 overflow-hidden shadow-xs">
          <!-- Visual Dish Photo Header -->
          <div class="relative h-52 sm:h-60 w-full bg-stone-900 overflow-hidden">
            <img 
              src="${aiDishPhoto}" 
              alt="${FlavorForgeUtils.escapeHTML(generated.title)}" 
              onerror="handleImageError(this, 'FlavorForge Chef')"
              class="w-full h-full object-cover object-center"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/35 to-black/15"></div>
            <div class="absolute top-3.5 left-4 right-4 flex flex-wrap items-center justify-between gap-2">
              <span class="px-3 py-1 rounded-full text-xs font-bold bg-terracotta-500 text-white shadow-sm">✨ Custom AI Rescue Creation</span>
              <span class="px-3 py-1 rounded-full text-xs font-semibold bg-black/55 text-white backdrop-blur-xs">⏱️ ${Number(generated.prepTimeMins) || 15} mins • 🔥 ~${Number(generated.calories) || 0} kcal/serving</span>
            </div>
            <div class="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-6">
              <h2 class="font-display text-xl sm:text-2xl font-bold text-white leading-snug drop-shadow-xs">${FlavorForgeUtils.escapeHTML(generated.title)}</h2>
            </div>
          </div>

          <div class="p-6 space-y-4">
            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Ingredients Used</h4>
              <ul class="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs sm:text-sm">
                ${generated.ingredients.map(ing => `<li class="bg-white px-3 py-1.5 rounded-lg border border-stone-200/80 font-medium">✓ ${FlavorForgeUtils.escapeHTML(ing)}</li>`).join('')}
              </ul>
            </div>

            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Cooking Method</h4>
              <ol class="space-y-2 text-xs sm:text-sm text-stone-800">
                ${generated.steps.map((st, i) => `
                  <li class="flex gap-2.5 items-start bg-white/80 p-3 rounded-xl border border-stone-200/60">
                    <span class="w-5 h-5 rounded-full bg-sage-600 text-white text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">${i + 1}</span>
                    <span>${FlavorForgeUtils.escapeHTML(st)}</span>
                  </li>
                `).join('')}
              </ol>
            </div>

            <div class="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
              <strong>💡 Chef's Rescue Tip:</strong> ${FlavorForgeUtils.escapeHTML(generated.chefTip)}
            </div>
          </div>
        </div>
      `;

      btn.disabled = false;
      btn.innerHTML = `<span>🪄</span><span>Regenerate Another Idea</span>`;
    }

    /**
     * 16B. DETERMINISTIC AI CHEF FALLBACK RECIPE BUILDER
     * Synthesizes a practical, diet-respecting recipe from the user's selected
     * fridge ingredients when an external LLM API key is not configured.
     */
    function buildSmartFallbackRecipe(items, mood, diet) {
      const normalized = items.map(i => normalizeIngredient(i));
      const hasVegOnly = diet === 'Vegetarian Only';
      const isHighProtein = diet === 'High Protein & Low Carb';

      // Filter out non-veg ingredients if Vegetarian Only is selected
      const nonVegCanonicals = new Set(['egg', 'chicken']);
      let usableItems = hasVegOnly
        ? items.filter((_, idx) => !nonVegCanonicals.has(normalized[idx]))
        : [...items];

      if (usableItems.length === 0) {
        usableItems = ['Potatoes', 'Onions', 'Paneer'];
      }

      const primary = usableItems[0];
      const secondary = usableItems[1] || 'Onions';
      const tertiary = usableItems[2] || 'Tomatoes';

      const moodTitlePrefix = {
        'Quick 15-Minute Skillet Meal': `Skillet ${primary} & ${secondary} Rescue Hash`,
        'Cozy Comfort Bowl / Soup': `Warm ${primary} & ${tertiary} Comfort Bowl`,
        'Crispy Street-Style Snack': `Crispy ${primary} & ${secondary} Street Bites`,
        'High-Protein College Dorm Hack': `Power ${primary} & ${secondary} Dorm Skillet`
      }[mood] || `FridgeRescue ${primary} & ${secondary} Medley`;

      const title = isHighProtein
        ? `${moodTitlePrefix} (High-Protein Edition)`
        : moodTitlePrefix;

      const prepTimeMins = mood === 'Cozy Comfort Bowl / Soup' ? 20 : 15;
      const calories = isHighProtein ? 310 : 345;

      const measuredIngredients = usableItems.map((item, idx) => {
        const canon = normalizeIngredient(item);
        if (canon === 'egg') return `3 Eggs (beaten)`;
        if (canon === 'potato') return `2 medium Potatoes (diced)`;
        if (canon === 'onion') return `1 medium Onion (chopped)`;
        if (canon === 'tomato') return `1 medium Tomato (chopped)`;
        if (canon === 'paneer') return `150g Paneer (cubed or crumbled)`;
        if (canon === 'bread') return `3 slices Bread (cubed or toasted)`;
        if (canon === 'rice') return `1.5 cups Cooked Rice`;
        return `${idx === 0 ? '1.5 cups' : '0.5 cup'} ${item}`;
      });
      measuredIngredients.push('1 tbsp Cooking Oil, Salt, Black Pepper & Chili Powder (assumed pantry staples)');

      const steps = [
        `Prep your fridge basket: dice or chop ${usableItems.slice(0, 3).join(', ')} into uniform bite-sized pieces for even cooking.`,
        `Heat 1 tbsp cooking oil in a skillet or saucepan over medium heat and season with a pinch of salt, pepper, and chili powder.`,
        mood === 'Cozy Comfort Bowl / Soup'
          ? `Sauté ${secondary} and ${tertiary} for 3 minutes, add ${primary} plus 1.5 cups water, and simmer 10 minutes until cozy and flavorful.`
          : `Add ${primary} and ${secondary} to the hot pan, tossing every 2 minutes so edges turn golden and aromatic.`,
        `Fold in any remaining ingredients (${tertiary}) and cook 2-3 minutes more until everything is piping hot and well combined.`,
        `Taste, adjust salt or spice if needed, and serve warm straight from the pan.`
      ];

      const chefTip = hasVegOnly
        ? `Because you selected Vegetarian Only, any egg or meat items were safely excluded and balanced with plant/dairy staples.`
        : `To stretch ${primary} even further without extra shopping, toss in leftover bread cubes or a spoonful of yogurt/milk right before finishing.`;

      return {
        title,
        prepTimeMins,
        calories,
        ingredients: measuredIngredients,
        steps,
        chefTip
      };
    }

    /**
     * 1. CANONICAL INGREDIENT NORMALIZER & SYNONYM MAP
     * Maps common singular/plural/regional names to canonical stems so
     * "Capsicum" == "Bell Pepper", "Curd" == "Yogurt", "Tomatoes" == "Tomato", etc.
     */
    const SYNONYM_MAP = {
      'egg': 'egg',
      'eggs': 'egg',
      'potato': 'potato',
      'potatoes': 'potato',
      'aloo': 'potato',
      'onion': 'onion',
      'onions': 'onion',
      'pyaz': 'onion',
      'tomato': 'tomato',
      'tomatoes': 'tomato',
      'rice': 'rice',
      'cooked rice': 'rice',
      'leftover rice': 'rice',
      'chawal': 'rice',
      'milk': 'milk',
      'paneer': 'paneer',
      'cottage cheese': 'paneer',
      'tofu': 'paneer',
      'bread': 'bread',
      'bread slices': 'bread',
      'toast': 'bread',
      'butter': 'butter',
      'ghee': 'butter',
      'cheese': 'cheese',
      'cheddar': 'cheese',
      'mozzarella': 'cheese',
      'yogurt': 'yogurt',
      'curd': 'yogurt',
      'dahi': 'yogurt',
      'garlic': 'garlic',
      'garlic cloves': 'garlic',
      'ginger': 'ginger',
      'adrak': 'ginger',
      'cilantro': 'cilantro',
      'coriander': 'cilantro',
      'fresh coriander': 'cilantro',
      'dhaniya': 'cilantro',
      'green chili': 'green chili',
      'green chilies': 'green chili',
      'green chilli': 'green chili',
      'chili': 'green chili',
      'bell pepper': 'bell pepper',
      'bell peppers': 'bell pepper',
      'capsicum': 'bell pepper',
      'shimla mirch': 'bell pepper',
      'gram flour': 'gram flour',
      'besan': 'gram flour',
      'chickpea flour': 'gram flour',
      'pasta': 'pasta',
      'penne': 'pasta',
      'macaroni': 'pasta',
      'spaghetti': 'pasta',
      'green peas': 'green peas',
      'peas': 'green peas',
      'matar': 'green peas',
      'spinach': 'spinach',
      'palak': 'spinach',
      'oats': 'oats',
      'rolled oats': 'oats',
      'carrot': 'carrot',
      'carrots': 'carrot',
      'flattened rice': 'flattened rice',
      'poha': 'flattened rice',
      'peanuts': 'peanuts',
      'peanut': 'peanuts',
      'groundnuts': 'peanuts',
      'lemon': 'lemon',
      'lemon juice': 'lemon',
      'lime': 'lemon',
      'lentils': 'lentils',
      'dal': 'lentils',
      'yellow lentils': 'lentils',
      'noodles': 'noodles',
      'hakka noodles': 'noodles',
      'cabbage': 'cabbage',
      'patta gobhi': 'cabbage',
      'soy sauce': 'soy sauce',
      'soya sauce': 'soy sauce',
      'roti': 'roti',
      'chapati': 'roti',
      'tortilla': 'roti',
      'ketchup': 'ketchup',
      'tomato ketchup': 'ketchup',
      'sweet corn': 'sweet corn',
      'corn': 'sweet corn',
      'semolina': 'semolina',
      'suji': 'semolina',
      'rava': 'semolina',
      'mushroom': 'mushroom',
      'mushrooms': 'mushroom',
      'chickpeas': 'chickpeas',
      'chana': 'chickpeas',
      'garbanzo beans': 'chickpeas',
      'chicken': 'chicken',
      'banana': 'banana',
      'bananas': 'banana',
      'wheat flour': 'wheat flour',
      'atta': 'wheat flour',
      'whole wheat flour': 'wheat flour'
    };

    const DISPLAY_NAMES = {
      'egg': 'Eggs',
      'potato': 'Potatoes',
      'onion': 'Onions',
      'tomato': 'Tomatoes',
      'rice': 'Rice',
      'milk': 'Milk',
      'paneer': 'Paneer',
      'bread': 'Bread',
      'butter': 'Butter',
      'cheese': 'Cheese',
      'yogurt': 'Yogurt / Curd',
      'garlic': 'Garlic',
      'ginger': 'Ginger',
      'cilantro': 'Coriander (Cilantro)',
      'green chili': 'Green Chili',
      'bell pepper': 'Bell Pepper / Capsicum',
      'gram flour': 'Besan (Gram Flour)',
      'pasta': 'Pasta',
      'green peas': 'Green Peas',
      'spinach': 'Spinach (Palak)',
      'oats': 'Rolled Oats',
      'carrot': 'Carrots',
      'flattened rice': 'Poha (Flattened Rice)',
      'peanuts': 'Peanuts',
      'lemon': 'Lemon',
      'lentils': 'Lentils (Dal)',
      'noodles': 'Noodles',
      'cabbage': 'Cabbage',
      'soy sauce': 'Soy Sauce',
      'roti': 'Roti / Chapati',
      'ketchup': 'Tomato Ketchup',
      'sweet corn': 'Sweet Corn',
      'semolina': 'Semolina (Rava / Suji)',
      'mushroom': 'Mushrooms',
      'chickpeas': 'Chickpeas (Chana)',
      'chicken': 'Chicken',
      'banana': 'Banana',
      'wheat flour': 'Wheat Flour (Atta)'
    };

    function normalizeIngredient(raw) {
      if (!raw) return '';
      const cleaned = raw.toLowerCase().trim().replace(/\s+/g, ' ');
      if (SYNONYM_MAP[cleaned]) return SYNONYM_MAP[cleaned];
      // Strip trailing 's' or 'es' as a fallback stem check
      const singular = cleaned.endsWith('es') ? cleaned.slice(0, -2) : (cleaned.endsWith('s') ? cleaned.slice(0, -1) : cleaned);
      return SYNONYM_MAP[singular] || cleaned;
    }

    function formatDisplayName(canonical) {
      if (DISPLAY_NAMES[canonical]) return DISPLAY_NAMES[canonical];
      return canonical.replace(/\b\w/g, ch => ch.toUpperCase());
    }

    /**
     * 2. CATEGORIZED PANTRY CATALOG FOR QUICK-TAP SELECTOR
     */
    const PANTRY_CATALOG = [
      {
        category: 'Fridge Staples & Dairy',
        icon: '🥚',
        items: ['egg', 'milk', 'paneer', 'butter', 'cheese', 'yogurt', 'chicken']
      },
      {
        category: 'Fresh Vegetables',
        icon: '🥔',
        items: ['potato', 'onion', 'tomato', 'bell pepper', 'spinach', 'carrot', 'green peas', 'cabbage', 'mushroom', 'sweet corn', 'green chili', 'garlic', 'ginger', 'cilantro', 'lemon', 'banana']
      },
      {
        category: 'Grains, Bread & Pantry',
        icon: '🌾',
        items: ['rice', 'bread', 'roti', 'pasta', 'noodles', 'oats', 'flattened rice', 'semolina', 'gram flour', 'wheat flour', 'lentils', 'chickpeas', 'peanuts', 'soy sauce', 'ketchup']
      }
    ];

    /**
     * 3. SMART KITCHEN SUBSTITUTION MATRIX
     */
    const SUBSTITUTION_MATRIX = {
      'butter': 'Use Cooking Oil or Ghee at a 1:1 ratio for sautéing and frying.',
      'milk': 'Mix 2 tbsp Milk Powder with warm water, or use unsweetened oat/soy milk.',
      'yogurt': 'Use sour cream, or stir 1 tsp lemon juice into 1/2 cup milk and rest 5 mins.',
      'paneer': 'Substitute extra-firm Tofu or cubed boiled Potatoes/Chickpeas.',
      'bread': 'Use Roti / Chapati slices, dinner rolls, or toasted crackers.',
      'roti': 'Use sandwich bread slices or flour tortillas.',
      'cheese': 'Use extra grated Paneer, melted butter + pinch of salt, or omit.',
      'tomato': 'Use 1 tbsp Tomato Ketchup + a splash of lemon juice or vinegar.',
      'onion': 'Use thinly sliced shallots, spring onion whites, or a pinch of asafoetida (hing).',
      'bell pepper': 'Swap in diced carrots, cabbage, or green beans.',
      'spinach': 'Use finely chopped cabbage, kale, or methi (fenugreek) leaves.',
      'garlic': 'Use 1/2 tsp garlic powder or extra ginger + onion.',
      'cilantro': 'Use fresh parsley, mint leaves, or spring onion greens.',
      'lemon': 'Use a splash of white/apple cider vinegar or a pinch of amchur (dry mango powder).',
      'soy sauce': 'Mix 1/2 tsp Worcestershire sauce with a pinch of salt and sugar, or use ketchup + vinegar.',
      'gram flour': 'Use fine semolina (rava) or whole wheat flour (atta) with a pinch of spice.',
      'peanuts': 'Use roasted sunflower seeds, pumpkin seeds, or crushed cashews.'
    };

    /**
     * 16. AI CHEF IMPROVISER (Gemini API + Intelligent Culinary Synthesis Fallback)
     */
    function syncUI() {
      renderPantryUI();
      renderRecipes();
      updateSavedBadge();
    }

    window.addEventListener('DOMContentLoaded', async () => {
      setupAutocomplete();
      try {
        const response = await fetch('./recipes.json', { cache: 'no-store' });
        if (!response.ok) throw new Error(`Recipe data request failed (${response.status})`);
        const recipeData = await response.json();
        if (!Array.isArray(recipeData) || recipeData.length === 0) throw new Error('Recipe data is empty or invalid');
        RECIPES_DB = recipeData;
        FlavorForgeUtils.log('info', 'recipe_database_loaded', { count: RECIPES_DB.length });
      } catch (error) {
        FlavorForgeUtils.log('error', 'recipe_database_load_failed', { message: error.message });
        const banner = document.getElementById('match-banner-text');
        if (banner) banner.textContent = 'Recipe data could not load. Please run this project with the local server instructions in README.md.';
      }
      await loadSavedFavorites();
      ['egg', 'potato', 'onion'].forEach(item => selectedPantry.add(item));
      syncUI();
    });
