require('dotenv').config();
const express = require('express');
const path = require('node:path');
const fs = require('node:fs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const db = require('./server/db');
const { validateFavoriteId, validateAiRequest, validateGeneratedRecipe } = require('./server/validation');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const recipes = JSON.parse(fs.readFileSync(path.join(__dirname, 'recipes.json'), 'utf8'));
const validRecipeIds = new Set(recipes.map(recipe => recipe.id));
const distDir = path.join(__dirname, 'dist');
const staticDir = fs.existsSync(distDir) ? distDir : __dirname;

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '12kb' }));
app.use('/api/ai', rateLimit({ windowMs: 60_000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false }));

const listFavorites = db.prepare('SELECT recipe_id FROM favorites ORDER BY created_at DESC');
const addFavorite = db.prepare('INSERT OR IGNORE INTO favorites (recipe_id) VALUES (?)');
const removeFavorite = db.prepare('DELETE FROM favorites WHERE recipe_id = ?');

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.get('/api/favorites', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ favorites: listFavorites.all().map(row => row.recipe_id) });
});

app.put('/api/favorites/:id', (req, res) => {
  const id = validateFavoriteId(req.params.id, validRecipeIds);
  if (!id) return res.status(400).json({ error: 'Unknown recipe id.' });
  addFavorite.run(id);
  res.status(200).json({ saved: true, recipeId: id });
});

app.delete('/api/favorites/:id', (req, res) => {
  const id = validateFavoriteId(req.params.id, validRecipeIds);
  if (!id) return res.status(400).json({ error: 'Unknown recipe id.' });
  removeFavorite.run(id);
  res.json({ saved: false, recipeId: id });
});

app.post('/api/ai/recipe', async (req, res) => {
  const input = validateAiRequest(req.body);
  if (!input) return res.status(400).json({ error: 'Invalid recipe request.' });
  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({ error: 'AI provider is not configured.' });
  }

  const prompt = `Create one practical, safe home-style recipe. Use these available ingredients: ${input.items.join(', ') || 'common pantry ingredients'}. Style: ${input.mood}. Diet: ${input.diet}. Return JSON with title, prepTimeMins, calories, ingredients (string array), steps (string array), chefTip. Do not claim allergens are absent unless ingredients support it.`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);
  try {
    const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: 'application/json' }
      })
    });
    if (!response.ok) {
      console.error(JSON.stringify({ event: 'ai_provider_http_error', status: response.status, at: new Date().toISOString() }));
      return res.status(502).json({ error: 'AI provider request failed.' });
    }
    const payload = await response.json();
    const raw = payload?.candidates?.[0]?.content?.parts?.[0]?.text;
    let recipe;
    try { recipe = JSON.parse(raw || ''); } catch { recipe = null; }
    if (!validateGeneratedRecipe(recipe)) {
      console.error(JSON.stringify({ event: 'ai_invalid_response', at: new Date().toISOString() }));
      return res.status(502).json({ error: 'AI returned an invalid recipe.' });
    }
    res.json({ recipe });
  } catch (error) {
    console.error(JSON.stringify({ event: 'ai_request_error', name: error.name, at: new Date().toISOString() }));
    res.status(error.name === 'AbortError' ? 504 : 502).json({ error: 'AI service is temporarily unavailable.' });
  } finally {
    clearTimeout(timeout);
  }
});

app.use(express.static(staticDir));
app.get('*', (_req, res) => res.sendFile(path.join(staticDir, 'index.html')));

app.listen(PORT, () => console.log(`FlavorForge running at http://localhost:${PORT}`));
