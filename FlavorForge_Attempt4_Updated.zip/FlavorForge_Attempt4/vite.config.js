const { defineConfig } = require('vite');
module.exports = defineConfig({
  root: '.',
  build: { outDir: 'dist', emptyOutDir: true },
  server: { proxy: { '/api': 'http://localhost:3000' } }
});
